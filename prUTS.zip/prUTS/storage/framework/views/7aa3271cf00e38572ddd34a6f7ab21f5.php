<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
</head>
<body>
    <h1>Informasi Pribadi</h1>
    <p>Nama: Sabda Gusti Syailendra</p>
    <p>NIM: 22104410077</p>
    <p>Jurusan: Teknik informatika</p>
    <p>Semester: 4</p>
    <hr>
    <p>Nama: Rizki Ramadhan</p>
    <p>NIM: 22104410088</p>
    <p>Jurusan: Teknik Informatika</p>
    <p>Semester: 4</p>
    <hr>
    <p>Nama: Mohammad Husaini Azhar</p>
    <p>NIM: 22104410093</p>
    <p>Jurusan: Teknik Informatika</p>
    <p>Semester: 4</p>
    <hr>
    <p>Nama: Andika Maulana R.U</p>
    <p>NIM: 22104410105</p>
    <p>Jurusan: Teknik Informatika</p>
    <p>Semester: 4</p>
    <hr>
    <p>Nama: Sahrul Ramadhan</p>
    <p>NIM: 22104414002</p>
    <p>Jurusan: Teknik Informatika</p>
    <p>Semester: 4</p>

    <script>
        // Ambil session "pass-key"
        var passKey = "<?php echo e(session('pass-key')); ?>";
        
        // Jika session tidak kosong, tampilkan pesan
        if (passKey) {
            alert(passKey);
        }
    </script>

</body>
</html>
<?php /**PATH C:\Users\sbdgu\prUTS\resources\views/uts/index.blade.php ENDPATH**/ ?>