<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\UTSController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
// routes/web.php

Route::get('/uts', function () {
    return view('uts.index');
});

Route::get('/uts/index', [UTSController::class, 'index']);
Route::get('/uts/create', [UTSController::class, 'create']);
Route::post('/uts', [UTSController::class, 'store']);
Route::get('/uts/list', [UTSController::class, 'showList']);

