<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UTSController extends Controller
{
    // Method untuk menampilkan data mahasiswa
    public function showList()
    {
        // Di sini kamu bisa mengambil data mahasiswa dari database atau dari sumber lainnya
        // Misalnya, kamu memiliki array data dummy sebagai contoh
        $mahasiswa = [
            ['nama' => 'Sabda Gusti Syailendra'],
            ['nama' => 'Rizki Ramadhan'],
            ['nama' => 'Mohammad Husaini Azhar'],
            ['nama' => 'Andika Maulana R.U'],
            ['nama' => 'Sahrul Ramadhan'],
            
        ];

        // Kirim data mahasiswa ke view list.blade.php
        return view('uts.list', compact('mahasiswa'));
    }

    public function create()
    {
        return view('uts.create');
    }

    // Method untuk menyimpan data siswa
    public function store(Request $request)
    {
        

        // Set session dengan pesan "data mahasiswa berhasil disimpan"
        $request->session()->flash('pass-key', 'data mahasiswa berhasil disimpan');

        return redirect('/uts');
        
    }
}


